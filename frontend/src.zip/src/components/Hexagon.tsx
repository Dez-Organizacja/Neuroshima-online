import React from "react";
import { useState, useContext, useEffect } from "react";
import "./Hexagon.css";
import { ActionData } from "./ActionTypes"
import { useGameSocketContext } from "../websockets/gameSocketContext";
import { useProcesedGameState, GameState } from "../Dlaigora";

type HexagonProps = {
    x: number;
    y: number;
    poz1: number;
    poz2: number;
    size?: number;
    color?: string;
    opacity?: number;
    rotation?: number;
    onClick?: () => void;
    children?: React.ReactNode;
    sendAction? : (action : ActionData) => void;
    gameState : GameState;
};

export function ClickCheck(x: number, y: number, gameState : GameState | undefined, sendAction : ((action : ActionData) => void) | undefined, rotation: number) : void {
    if(y === 999) return;
    if(!gameState){
        return;
    }
    if(!sendAction){
        return;
    }
    if(gameState.view.uiState.mode === "rotation") {
        const field = gameState.view.availableActions.board.find(field =>
            field[0] === x &&
            field[1] === y
        );
        if(!field) return;
        
        const action: ActionData = {
            type: "rotate",
            rotation: ((rotation - 30) / 60)
        };
        sendAction(action);
        return;
    }
    if(y === -1) {
        if(gameState.view.availableActions.hand[x]) {
            console.log("Click accepted (hand) : ", { x, y });
            const action: ActionData = {
                type: "hand",
                slot: x
            };
            sendAction(action);
        }
    } else {
        const Pair = [x, y];
        const field = gameState.view.availableActions.board.find(field =>
            field[0] === Pair[0] &&
            field[1] === Pair[1]
        );
        if(field) {
            console.log("Click accepted (board) : ", { x, y });

            const Pair = [x, y];
            const action: ActionData = {
                type: "board",
                pos: Pair
            };
            sendAction(action);
        }
    }
}

const Hexagon: React.FC<HexagonProps> = ({
    x,
    y,
    poz1,
    poz2,
    size = 100,
    color = "#4CAF50",
    opacity = 0.3,
    rotation = 0,
    onClick,
    children,
    sendAction,
    gameState,
}) => {

    const height = size * 0.866;

    const canRotate = gameState.view.uiState.mode === "rotation";
    const [Rotation, setRotation] = useState(rotation);
    useEffect(() => {

        const handleKeyDown = (event: KeyboardEvent) => {
            if(!canRotate) return;

            if (event.key === "ArrowLeft") {
                setRotation(prev => (prev + 300) % 360);
            }

            if (event.key === "ArrowRight") {
                setRotation(prev => (prev + 60) % 360);
            }
        };

        window.addEventListener("keydown", handleKeyDown);

        return () => {
            window.removeEventListener("keydown", handleKeyDown);
        };

    }, [canRotate]);

    return (
        <div
            className="hexagon"
            // onClick={onClick}
            // onClick={() => console.log("Clicked hex:", { poz1, poz2 })}
            onClick={() => ClickCheck(poz1, poz2, gameState, sendAction, Rotation)}
        style={{
            width: size,
            height: height,
            backgroundColor: color,
            opacity: opacity,
            position: "absolute",
            left: x - (size / 2),
            top: y - (height / 2),
            transform: `rotate(${Rotation}deg) scale(1)`,
        }}
        >
        < div className="hexagon-content">{children}</div>
         </div>
    );
};

export default Hexagon;