import { useState, useEffect } from "react";
import { useGameSocketContext } from "./websockets/gameSocketContext";

type BoardCell = {
    pos : [number, number];
    unit : {
        name : string,
        faction : string,
        rotation : number,
        damage : number,
        wired : number,
        ability_used : boolean,
    }
}
export type GameState = {
    view : {
        state : {
            factions : [string, string]
            board : BoardCell[]
            hands : {
                [key : string] : {tokens : string[]}
            }
        }
        availableActions : {
            hand : boolean[]
            board : [number, number][]
            buttons : string[]
        }
        uiState : {
            faction : string,
            mode : string,
            message : string
        }
    }
}

export function useProcesedGameState(){
    const {latestMessage} = useGameSocketContext();
    const [gameState, setGameState] = useState<GameState | null>(null)
    useEffect(() => {
        if(!latestMessage){
            return;
        }
        if(latestMessage.messageType === "ACTION_RESPONSE" && latestMessage.gameView){   
            setGameState({
                view : latestMessage.gameView as GameState["view"]
            });
        }
        if(latestMessage.messageType === "NEWGAME_RESPONSE" && latestMessage.gameView){
            setGameState({
                view : latestMessage.gameView as GameState["view"]
            })
            if(typeof latestMessage.createdGameId === "string"){
                localStorage.setItem("gameId", latestMessage.createdGameId);
            }
            return;
        }
        if (latestMessage.messageType === "ERROR") {
            console.error(latestMessage.error);
            return;
        }
    }, [latestMessage]);

    return { gameState};
}