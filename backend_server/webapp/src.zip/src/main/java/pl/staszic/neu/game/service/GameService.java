package pl.staszic.neu.game.service;
import pl.staszic.neu.messages.*;
import pl.staszic.neu.messages.game.*;
import pl.staszic.neu.messages.room.*;

import java.util.Set;

public interface GameService {
    CreateNewRoomResponse createNewRoom(String clientId, CreateNewRoomRequest request);

    JoinRoomResponse joinRoom(String clientId, JoinRoomRequest request);

    LeaveRoomResponse leaveRoom(String clientId, LeaveRoomRequest request);

    KickFromRoomResponse kickFromRoom(String clientId, KickFromRoomRequest request);

    GetRoomStatusResponse getRoomStatus(String clientId, GetRoomStatusRequest request);

    GetUserDataResponse getUserData(String clientId, GetUserDataRequest request);

    SetInRoomAttributesResponse setInRoomAttributes(String clientId, SetInRoomAttributesRequest request);

    SetRoomPolicyResponse setRoomPolicy(String clientId, SetRoomPolicyRequest request);

    GetRoomsListResponse getRoomsList(String clientId, GetRoomsListRequest request);

    NewGameResponse startNewGame(String clientId, NewGameRequest request);

    ActionResponse processAction(String clientId, ActionRequest request);

    EndGameResponse endGame(String clientId, EndGameRequest request);

    void handleClientDisconnect(String clientId);

    void registerClientUsername(String clientId, String username);

    String getAffiliation(String clientId);

    Set<String> getClientIdsInRoom(String roomId);
}
